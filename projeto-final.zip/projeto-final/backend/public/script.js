const API_URL = "/products"

const form = document.getElementById("productForm")
const container = document.getElementById("productsContainer")
const cancelBtn =  document.getElementById("cancelBtn")

const time = document.getElementById("time")

let editId = null;

async function loadProducts() {
    container.innerHTML = "<p>Carregando...</p>"

    try{
        const res = await fetch(API_URL);
        const products = await res.json()

        container.innerHTML = "";

        products.forEach((p) => {
            const card = document.createElement('div')
            card.className = "card";
            card.innerHTML = `
            <h3>${p.name}</h3>
            <p>${p.description}</p>
            <p class="price">R$ ${p.price.toFixed(2)}</p>
            <button onclick="editProduct('${p._id}', '${p.name}', '${p.price}','${p.description}')">Editar</button>
            <button onclick="excludeProduct('${p._id}')">Excluir</button>
            `;

            container.appendChild(card);
        });

    }catch(err){
        container.innerHTML = "<p>Erro ao carregar produtos!</p>"
    }
}

//loadProducts();

form.addEventListener('submit', async(e)=>{
    e.preventDefault();

    const product = {
        name: document.getElementById('name').value,
        price: parseFloat(document.getElementById('price').value),
        description: document.getElementById('description').value

    }

    try {
        const methodl = editId ? "PUT" : "POST";
        const url = editId ? `${API_URL}/${editId}` : API_URL

        const res = await fetch(url, {
            method: methodl,
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(product)
        });

        if(res.ok){
            form.reset();
            cancelEdition();
            loadProducts();
        }else{
            alert('Erro ao salvar produto.')
        }
    } catch{
        alert('Falha no servidor! Tente mais tarde.')
    }
})

async function excludeProduct(id) {
    if(!confirm("Deseja excluir este produto?")) return;

    try {
        const res = await fetch(`${API_URL}/${id}`, { method: "DELETE" });
        if (!res.ok) throw new Error('Falha ao excluir produto');
        loadProducts(); 
    } catch(err) {
        console.error(err);
        alert('Erro ao excluir produto!');
    }
}

function editProduct(id, name, price, description){
    document.getElementById('name').value = name;
    document.getElementById('price').value = price;
    document.getElementById('description').value = description;
    editId = id;

    form.querySelector("button[type='submit']").textContent = 'Salvar alterações';
    cancelBtn.style.display = "inline-block";

}

function cancelEdition(){
    editId = null
    form.reset()
    form.querySelector("button[type='submit']").textContent = "cadastrar"
    cancelBtn.style.display = "none"
}

loadProducts();