import dotenv from 'dotenv';
import express from 'express'
import product from './models/Product.js'
import mongoose from 'mongoose'
import path from 'path'
import { fileURLToPath  } from 'url'
import productsRouter from './routes/products.js'
import { appendFile } from 'fs'

const app = express();

dotenv.config({ path: path.resolve('../.env') });

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.json());

const MONGO_URI = process.env.MONGO_URI;

mongoose.connect(MONGO_URI)

  .then(() => console.log('conectado ao mongodb'))
  .catch(err=>{
    console.error("Erro ao conectar: ", err.message);
    process.exit(1)
  });

app.use('/products', productsRouter);
app.use(express.static(path.join(__dirname, '../public')));

app.get('/', (req, res)=>{
  res.sendFile(path.join(__dirname, '../public', 'index.html'));
})

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=>{
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});

const router = express.Router();